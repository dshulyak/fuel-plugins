#!/bin/bash

# It's a script which deploys your plugin
echo lbaas_simple > /tmp/lbaas_simple
